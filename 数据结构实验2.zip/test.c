#define _CRT_SECURE_NO_WARNINGS 1
#include"heap.h"
int main()
{
	char s[] = "{}()[]";
	char s1[] = "{)[]";
	char s2[] = "{]";



	//printf("%d\n", isValid_list(s));
	//printf("%d\n", isValid_list(s1));
	//printf("%d\n", isValid_list(s2));

	//printf("\n");

	printf("%d\n", isValid_array(s));
	printf("%d\n", isValid_array(s1));
	printf("%d\n", isValid_array(s2));


}